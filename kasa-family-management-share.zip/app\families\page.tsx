'use client'

import { useState, useEffect } from 'react'
import { 
  PlusIcon, 
  PencilIcon, 
  TrashIcon,
  EyeIcon,
  UserGroupIcon
} from '@heroicons/react/24/outline'
import Link from 'next/link'

// QWERTY to Hebrew keyboard mapping
const qwertyToHebrew: { [key: string]: string } = {
  // Lowercase letters
  'q': '/', 'w': "'", 'e': 'ק', 'r': 'ר', 't': 'א', 'y': 'ט', 'u': 'ו', 'i': 'ן', 'o': 'ם', 'p': 'פ',
  'a': 'ש', 's': 'ד', 'd': 'ג', 'f': 'כ', 'g': 'ע', 'h': 'י', 'j': 'ח', 'k': 'ל', 'l': 'ך',
  'z': 'ז', 'x': 'ס', 'c': 'ב', 'v': 'ה', 'b': 'נ', 'n': 'מ', 'm': 'צ',
  // Uppercase letters (with Shift)
  'Q': '/', 'W': "'", 'E': 'ק', 'R': 'ר', 'T': 'א', 'Y': 'ט', 'U': 'ו', 'I': 'ן', 'O': 'ם', 'P': 'פ',
  'A': 'ש', 'S': 'ד', 'D': 'ג', 'F': 'כ', 'G': 'ע', 'H': 'י', 'J': 'ח', 'K': 'ל', 'L': 'ך',
  'Z': 'ז', 'X': 'ס', 'C': 'ב', 'V': 'ה', 'B': 'נ', 'N': 'מ', 'M': 'צ',
  // Numbers and special characters
  '1': '1', '2': '2', '3': '3', '4': '4', '5': '5', '6': '6', '7': '7', '8': '8', '9': '9', '0': '0',
  '-': '-', '=': '=', '[': ']', ']': '[', '\\': '\\', ';': 'ף', "'": ',', ',': 'ת', '.': 'ץ', '/': '.',
  ' ': ' ' // Space
}

// Convert QWERTY input to Hebrew characters
const convertToHebrew = (text: string): string => {
  return text.split('').map(char => qwertyToHebrew[char] || char).join('')
}

// Handler for Hebrew input fields
const handleHebrewInput = (e: React.KeyboardEvent<HTMLInputElement>, currentValue: string, setValue: (value: string) => void) => {
  const input = e.currentTarget
  const cursorPosition = input.selectionStart || 0
  
  // Only convert if typing a regular character (not special keys like Backspace, Delete, Arrow keys, etc.)
  if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
    e.preventDefault()
    const hebrewChar = qwertyToHebrew[e.key] || e.key
    const newValue = currentValue.slice(0, cursorPosition) + hebrewChar + currentValue.slice(cursorPosition)
    setValue(newValue)
    
    // Set cursor position after the inserted character
    setTimeout(() => {
      input.setSelectionRange(cursorPosition + 1, cursorPosition + 1)
    }, 0)
  }
}

interface Family {
  _id: string
  name: string
  hebrewName?: string
  weddingDate: string
  husbandFirstName?: string
  husbandHebrewName?: string
  husbandFatherHebrewName?: string
  wifeFirstName?: string
  wifeHebrewName?: string
  wifeFatherHebrewName?: string
  husbandCellPhone?: string
  wifeCellPhone?: string
  email?: string
  phone?: string
  address?: string
  street?: string
  city?: string
  state?: string
  zip?: string
  paymentPlanId?: string // MongoDB ObjectId reference to PaymentPlan (may be missing for old families)
  currentPlan?: number // Legacy field - will be auto-converted to paymentPlanId
  currentPayment: number
  openBalance: number
  memberCount?: number
}

interface PaymentPlan {
  _id: string
  name: string
  yearlyPrice: number
  planNumber?: number // Optional for backward compatibility
}

export default function FamiliesPage() {
  const [families, setFamilies] = useState<Family[]>([])
  const [paymentPlans, setPaymentPlans] = useState<PaymentPlan[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingFamily, setEditingFamily] = useState<Family | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    hebrewName: '',
    weddingDate: '',
    husbandFirstName: '',
    husbandHebrewName: '',
    husbandFatherHebrewName: '',
    wifeFirstName: '',
    wifeHebrewName: '',
    wifeFatherHebrewName: '',
    husbandCellPhone: '',
    wifeCellPhone: '',
    address: '',
    street: '',
    phone: '',
    email: '',
    city: '',
    state: '',
    zip: '',
    paymentPlanId: '', // Store payment plan ID instead of plan number
    currentPayment: 0
  })

  useEffect(() => {
    fetchFamilies()
    fetchPaymentPlans()
  }, [])

  const fetchFamilies = async () => {
    try {
      const res = await fetch('/api/kasa/families')
      const data = await res.json()
      if (Array.isArray(data)) {
        setFamilies(data)
      } else {
        console.error('API error:', data)
        setFamilies([])
      }
    } catch (error) {
      console.error('Error fetching families:', error)
      setFamilies([])
    } finally {
      setLoading(false)
    }
  }

  const fetchPaymentPlans = async () => {
    try {
      const res = await fetch('/api/kasa/payment-plans')
      const data = await res.json()
      if (Array.isArray(data)) {
        setPaymentPlans(data)
        // No default selection - user must explicitly choose
      }
    } catch (error) {
      console.error('Error fetching payment plans:', error)
    }
  }

  const getPlanNameById = (planId?: string, currentPlan?: number): string => {
    // Debug logging
    if (!planId && currentPlan) {
      console.log(`Looking up plan for currentPlan: ${currentPlan}, paymentPlans:`, paymentPlans)
    }
    
    if (planId) {
      const plan = paymentPlans.find(p => p._id === planId)
      if (plan) {
        console.log(`Found plan by ID: ${plan.name}`)
        return plan.name
      }
      console.log(`Plan ID ${planId} not found in paymentPlans`)
    }
    
    // Fallback: try to find by currentPlan number (for old families)
    if (currentPlan && paymentPlans.length > 0) {
      console.log(`Trying to find plan by planNumber: ${currentPlan}`)
      const plan = paymentPlans.find((p: any) => p.planNumber === currentPlan)
      if (plan) {
        console.log(`Found plan by planNumber: ${plan.name}`)
        return plan.name
      }
      console.log(`Plan with planNumber ${currentPlan} not found. Available plans:`, paymentPlans.map((p: any) => ({ name: p.name, planNumber: p.planNumber, _id: p._id })))
    }
    
    console.log(`Could not find plan. planId: ${planId}, currentPlan: ${currentPlan}, paymentPlans count: ${paymentPlans.length}`)
    return 'Unknown Plan'
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editingFamily 
        ? `/api/kasa/families/${editingFamily._id}`
        : '/api/kasa/families'
      
      const method = editingFamily ? 'PUT' : 'POST'
      
      // Log what we're sending (for debugging)
      console.log('Submitting family data:', {
        method,
        url,
        formData: {
          ...formData,
          // Show Hebrew names specifically
          hebrewName: formData.hebrewName,
          husbandHebrewName: formData.husbandHebrewName,
          husbandFatherHebrewName: formData.husbandFatherHebrewName,
          wifeHebrewName: formData.wifeHebrewName,
          wifeFatherHebrewName: formData.wifeFatherHebrewName
        }
      })
      
      // Explicitly log Hebrew names to verify they're being sent
      console.log('Hebrew names being sent:', {
        hebrewName: formData.hebrewName || '(empty)',
        husbandHebrewName: formData.husbandHebrewName || '(empty)',
        husbandFatherHebrewName: formData.husbandFatherHebrewName || '(empty)',
        wifeHebrewName: formData.wifeHebrewName || '(empty)',
        wifeFatherHebrewName: formData.wifeFatherHebrewName || '(empty)'
      })
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      if (res.ok) {
        const result = await res.json()
        console.log('Family saved successfully:', result)
        setShowModal(false)
        setEditingFamily(null)
        resetForm()
        fetchFamilies()
      } else {
        const error = await res.json()
        console.error('Error saving family:', error)
        alert(`Error saving family: ${error.error || error.details || 'Unknown error'}`)
      }
    } catch (error) {
      console.error('Error saving family:', error)
      alert('Error saving family. Please check the console for details.')
    }
  }

  const handleEdit = (family: Family) => {
    setEditingFamily(family)
    
    // Use paymentPlanId directly (ID-based system)
    if (!family.paymentPlanId) {
      console.error('Family does not have paymentPlanId set')
      alert('Error: Family is missing payment plan. Please update the family.')
      return
    }
    
    setFormData({
      name: family.name,
      hebrewName: family.hebrewName || '',
      weddingDate: new Date(family.weddingDate).toISOString().split('T')[0],
      husbandFirstName: family.husbandFirstName || '',
      husbandHebrewName: family.husbandHebrewName || '',
      husbandFatherHebrewName: family.husbandFatherHebrewName || '',
      wifeFirstName: family.wifeFirstName || '',
      wifeHebrewName: family.wifeHebrewName || '',
      wifeFatherHebrewName: family.wifeFatherHebrewName || '',
      husbandCellPhone: family.husbandCellPhone || '',
      wifeCellPhone: family.wifeCellPhone || '',
      address: family.address || '',
      street: family.street || '',
      phone: family.phone || '',
      email: family.email || '',
      city: family.city || '',
      state: family.state || '',
      zip: family.zip || '',
      paymentPlanId: family.paymentPlanId,
      currentPayment: family.currentPayment
    })
    setShowModal(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this family?')) return
    
    try {
      const res = await fetch(`/api/kasa/families/${id}`, { method: 'DELETE' })
      if (res.ok) {
        fetchFamilies()
      }
    } catch (error) {
      console.error('Error deleting family:', error)
    }
  }

  const resetForm = () => {
    // No default selection - user must explicitly choose
    setFormData({
      name: '',
      hebrewName: '',
      weddingDate: '',
      husbandFirstName: '',
      husbandHebrewName: '',
      husbandFatherHebrewName: '',
      wifeFirstName: '',
      wifeHebrewName: '',
      wifeFatherHebrewName: '',
      husbandCellPhone: '',
      wifeCellPhone: '',
      address: '',
      street: '',
      phone: '',
      email: '',
      city: '',
      state: '',
      zip: '',
      paymentPlanId: '', // Empty - requires user selection
      currentPayment: 0
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-5xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Families
            </h1>
            <p className="text-gray-600">Manage family members and their information</p>
          </div>
          <button
            onClick={() => {
              resetForm()
              setEditingFamily(null)
              setShowModal(true)
            }}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl flex items-center gap-2 hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            <PlusIcon className="h-5 w-5" />
            Add Family
          </button>
        </div>

        <div className="glass-strong rounded-2xl shadow-xl overflow-hidden border border-white/30">
          <table className="min-w-full divide-y divide-white/20">
            <thead className="bg-white/20 backdrop-blur-sm">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Wedding Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Members</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Plan</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Balance</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white/10 divide-y divide-white/20">
              {families.map((family) => (
                <tr key={family._id} className="hover:bg-white/20 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap font-medium">{family.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {new Date(family.weddingDate).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap flex items-center gap-1">
                    <UserGroupIcon className="h-4 w-4" />
                    {family.memberCount || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">{getPlanNameById(family.paymentPlanId, family.currentPlan)}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    ${family.openBalance.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <Link
                        href={`/families/${family._id}`}
                        className="text-blue-600 hover:text-blue-800 transition-colors"
                        title="View Details"
                      >
                        <EyeIcon className="h-5 w-5" />
                      </Link>
                      <Link
                        href={`/families/${family._id}?tab=members&add=true`}
                        className="text-purple-600 hover:text-purple-800 transition-colors"
                        title="Add Child"
                      >
                        <PlusIcon className="h-5 w-5" />
                      </Link>
                      <button
                        onClick={() => handleEdit(family)}
                        className="text-green-600 hover:text-green-800 transition-colors"
                        title="Edit Family"
                      >
                        <PencilIcon className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(family._id)}
                        className="text-red-600 hover:text-red-800 transition-colors"
                        title="Delete Family"
                      >
                        <TrashIcon className="h-5 w-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <FamilyModal
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleSubmit}
            onClose={() => {
              setShowModal(false)
              setEditingFamily(null)
              resetForm()
            }}
            editing={!!editingFamily}
            paymentPlans={paymentPlans}
          />
          </div>
        )}
      </div>
    </div>
  )
}

function FamilyModal({
  formData,
  setFormData,
  onSubmit,
  onClose,
  editing,
  paymentPlans
}: {
  formData: any
  setFormData: (data: any) => void
  onSubmit: (e: React.FormEvent) => void
  onClose: () => void
  editing: boolean
  paymentPlans: PaymentPlan[]
}) {
  return (
    <div className="glass-strong rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/30">
        <h2 className="text-2xl font-bold mb-4">{editing ? 'Edit' : 'Add'} Family</h2>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Family Name *</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Family Name (Hebrew) *</label>
              <input
                type="text"
                required
                dir="rtl"
                lang="he"
                inputMode="text"
                value={formData.hebrewName}
                onChange={(e) => setFormData({ ...formData, hebrewName: e.target.value })}
                onKeyDown={(e) => handleHebrewInput(e, formData.hebrewName, (value) => setFormData({ ...formData, hebrewName: value }))}
                className="w-full border rounded px-3 py-2 text-right font-hebrew"
                placeholder="שם משפחה בעברית"
                style={{ fontFamily: 'Arial Hebrew, David, sans-serif' }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Husband First Name</label>
              <input
                type="text"
                value={formData.husbandFirstName}
                onChange={(e) => setFormData({ ...formData, husbandFirstName: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Husband First Name (Hebrew) *</label>
              <input
                type="text"
                required
                dir="rtl"
                lang="he"
                inputMode="text"
                value={formData.husbandHebrewName}
                onChange={(e) => setFormData({ ...formData, husbandHebrewName: e.target.value })}
                onKeyDown={(e) => handleHebrewInput(e, formData.husbandHebrewName, (value) => setFormData({ ...formData, husbandHebrewName: value }))}
                className="w-full border rounded px-3 py-2 text-right font-hebrew"
                placeholder="שם פרטי בעברית"
                style={{ fontFamily: 'Arial Hebrew, David, sans-serif' }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Husband's Father First Name (Hebrew)</label>
              <input
                type="text"
                dir="rtl"
                lang="he"
                inputMode="text"
                value={formData.husbandFatherHebrewName}
                onChange={(e) => setFormData({ ...formData, husbandFatherHebrewName: e.target.value })}
                onKeyDown={(e) => handleHebrewInput(e, formData.husbandFatherHebrewName, (value) => setFormData({ ...formData, husbandFatherHebrewName: value }))}
                className="w-full border rounded px-3 py-2 text-right font-hebrew"
                placeholder="שם פרטי של האב בעברית"
                style={{ fontFamily: 'Arial Hebrew, David, sans-serif' }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Wife First Name</label>
              <input
                type="text"
                value={formData.wifeFirstName}
                onChange={(e) => setFormData({ ...formData, wifeFirstName: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Wife First Name (Hebrew) *</label>
              <input
                type="text"
                required
                dir="rtl"
                lang="he"
                inputMode="text"
                value={formData.wifeHebrewName}
                onChange={(e) => setFormData({ ...formData, wifeHebrewName: e.target.value })}
                onKeyDown={(e) => handleHebrewInput(e, formData.wifeHebrewName, (value) => setFormData({ ...formData, wifeHebrewName: value }))}
                className="w-full border rounded px-3 py-2 text-right font-hebrew"
                placeholder="שם פרטי בעברית"
                style={{ fontFamily: 'Arial Hebrew, David, sans-serif' }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Wife's Father First Name (Hebrew)</label>
              <input
                type="text"
                dir="rtl"
                lang="he"
                inputMode="text"
                value={formData.wifeFatherHebrewName}
                onChange={(e) => setFormData({ ...formData, wifeFatherHebrewName: e.target.value })}
                onKeyDown={(e) => handleHebrewInput(e, formData.wifeFatherHebrewName, (value) => setFormData({ ...formData, wifeFatherHebrewName: value }))}
                className="w-full border rounded px-3 py-2 text-right font-hebrew"
                placeholder="שם פרטי של האב בעברית"
                style={{ fontFamily: 'Arial Hebrew, David, sans-serif' }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Husband Cell Phone</label>
              <input
                type="tel"
                value={formData.husbandCellPhone}
                onChange={(e) => setFormData({ ...formData, husbandCellPhone: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Wife Cell Phone</label>
              <input
                type="tel"
                value={formData.wifeCellPhone}
                onChange={(e) => setFormData({ ...formData, wifeCellPhone: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium mb-1">Street</label>
              <input
                type="text"
                value={formData.street}
                onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">City</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">State</label>
              <input
                type="text"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Phone</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Wedding Date *</label>
              <input
                type="date"
                required
                value={formData.weddingDate}
                onChange={(e) => setFormData({ ...formData, weddingDate: e.target.value })}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Payment Plan *</label>
              <select
                required
                value={formData.paymentPlanId || ''}
                onChange={(e) => setFormData({ ...formData, paymentPlanId: e.target.value })}
                className="w-full border rounded px-3 py-2"
              >
                <option value="">Select a payment plan...</option>
                {paymentPlans.map((plan) => (
                  <option key={plan._id} value={plan._id}>
                    {plan.name} - ${plan.yearlyPrice.toLocaleString()}/year
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex gap-4 justify-end mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all duration-200 transform hover:scale-105"
            >
              {editing ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
    </div>
  )
}

